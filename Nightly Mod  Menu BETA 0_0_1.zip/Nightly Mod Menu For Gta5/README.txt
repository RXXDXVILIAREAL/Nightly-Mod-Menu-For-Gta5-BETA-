BETA VERSION OF NIGHTLY NOT ABLE FOR USE!!!

What Is Nightly Menu - 
Nightly Menu Is a New Up Coming Free Gta5 Online Mod Menu By Rxxdxvilia.

What Is There In Nightly Menu -
Basic Options Like - 
Self
Online 
Gane 
Settings 
Misc (Unknowncheats.me Description Outdated)
Players
Lua Scripts 
Creds

Updates In The Future.